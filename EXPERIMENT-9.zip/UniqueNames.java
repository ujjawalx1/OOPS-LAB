
import java.util.HashSet;
import java.util.Arrays;

public class UniqueNames {
    public static void main(String[] args) {
        String[] names = {"Aman", "Varchasv", "Sourabh", "Varchasv", "Aman"};
        HashSet<String> nameSet = new HashSet<>(Arrays.asList(names));

        // Check if "Sourabh" exists
        if (nameSet.contains("Sourabh")) {
            System.out.println("Sourabh is in the set.");
        }

        // Print unique names
        for (String name : nameSet) {
            System.out.println(name);
        }
    }
}
