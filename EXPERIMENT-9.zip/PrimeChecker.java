
import java.util.ArrayList;

public class PrimeChecker {
    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i : new int[]{2, 3, 4, 5, 6, 7, 8, 9, 10}) {
            numbers.add(i); // Autoboxing
        }

        for (int num : numbers) {
            if (isPrime(num)) {
                System.out.println(num + " is a prime number.");
            } else {
                System.out.println(num + " is not a prime number.");
            }
        }
    }

    public static boolean isPrime(int n) {
        if (n <= 1) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
