
import java.util.HashMap;
import java.util.Map;

public class ProductInventory {
    public static void main(String[] args) {
        HashMap<Integer, Integer> inventory = new HashMap<>();
        inventory.put(1, 100);
        inventory.put(2, 200);
        inventory.put(3, 300);

        // Update quantity of product 2
        inventory.put(2, 250);

        // Remove product 1
        inventory.remove(1);

        // Display inventory
        for (Map.Entry<Integer, Integer> entry : inventory.entrySet()) {
            System.out.println("Product ID: " + entry.getKey() + ", Quantity: " + entry.getValue());
        }
    }
}
