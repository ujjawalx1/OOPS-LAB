import java.io.*;
import java.util.Scanner;

public class StudentFileWriter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            FileWriter writer = new FileWriter("student.txt", true);
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Roll Number: ");
            String roll = scanner.nextLine();
            System.out.print("Enter Grade: ");
            String grade = scanner.nextLine();

            writer.write("Name: " + name + ", Roll Number: " + roll + ", Grade: " + grade + "\n");
            writer.close();
            System.out.println("Student information saved.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
        }

        scanner.close();
    }
}