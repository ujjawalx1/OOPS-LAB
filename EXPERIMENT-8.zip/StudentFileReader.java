import java.io.*;

public class StudentFileReader {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("student.txt");
            BufferedReader br = new BufferedReader(fr);

            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }

            br.close();
            fr.close();
        } catch (FileNotFoundException e) {
            System.out.println("student.txt file not found.");
        } catch (IOException e) {
            System.out.println("Error reading the file.");
        }
    }
}