import java.io.*;
import java.util.Scanner;

public class WordCharCounter {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter file name: ");
        String fileName = input.nextLine();

        int wordCount = 0;
        int charCount = 0;

        try {
            FileReader fr = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fr);
            String line;

            while ((line = br.readLine()) != null) {
                String[] words = line.trim().split("\\s+");
                if (!line.trim().isEmpty()) {
                    wordCount += words.length;
                    charCount += line.replaceAll("\\s+", "").length();
                }
            }

            br.close();
            fr.close();

            System.out.println("Total Words: " + wordCount);
            System.out.println("Total Characters (excluding whitespace): " + charCount);
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }

        input.close();
    }
}