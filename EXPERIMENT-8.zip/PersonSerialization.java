import java.io.*;

class Person implements Serializable {
    String name;
    int age;

    Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

public class PersonSerialization {
    public static void main(String[] args) {
        Person person = new Person("Ravi", 25);

        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("person.txt"));
            oos.writeObject(person);
            oos.close();

            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("person.txt"));
            Person deserializedPerson = (Person) ois.readObject();
            ois.close();

            System.out.println("Deserialized Person:");
            System.out.println("Name: " + deserializedPerson.name);
            System.out.println("Age: " + deserializedPerson.age);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Serialization error: " + e.getMessage());
        }
    }
}