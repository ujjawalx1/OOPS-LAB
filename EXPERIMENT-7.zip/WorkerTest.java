abstract class Worker {
    String name;
    Worker(String name) {
        this.name = name;
    }
    abstract double computePay();
    abstract void displayInfo();
}

class FullTimeWorker extends Worker {
    double monthlySalary;

    FullTimeWorker(String name, double monthlySalary) {
        super(name);
        this.monthlySalary = monthlySalary;
    }

    @Override
    double computePay() {
        return monthlySalary;
    }

    @Override
    void displayInfo() {
        System.out.println("Full-Time Worker: " + name + ", Salary: " + computePay());
    }
}

class PartTimeWorker extends Worker {
    int hoursWorked;
    double hourlyRate;

    PartTimeWorker(String name, int hoursWorked, double hourlyRate) {
        super(name);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    @Override
    double computePay() {
        return hoursWorked * hourlyRate;
    }

    @Override
    void displayInfo() {
        System.out.println("Part-Time Worker: " + name + ", Pay: " + computePay());
    }
}

public class WorkerTest {
    public static void main(String[] args) {
        Worker ft = new FullTimeWorker("Alice", 3000);
        Worker pt = new PartTimeWorker("Bob", 80, 20);

        ft.displayInfo();
        pt.displayInfo();
    }
}