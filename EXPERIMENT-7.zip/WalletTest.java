interface Wallet {
    void addFunds(double amount);
    void spendFunds(double amount);
}

class DigitalWallet implements Wallet {
    private double balance = 0;

    @Override
    public void addFunds(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Added: $" + amount);
        }
    }

    @Override
    public void spendFunds(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Spent: $" + amount);
        } else {
            System.out.println("Insufficient funds or invalid amount.");
        }
    }

    public double getBalance() {
        return balance;
    }
}

public class WalletTest {
    public static void main(String[] args) {
        DigitalWallet myWallet = new DigitalWallet();
        myWallet.addFunds(100);
        myWallet.spendFunds(30);
        myWallet.spendFunds(80);
        System.out.println("Final Balance: $" + myWallet.getBalance());
    }
}