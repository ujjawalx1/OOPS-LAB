interface Remote {
    void powerOn();
    void powerOff();
    void changeChannel(int channel);
}

class Television implements Remote {
    @Override
    public void powerOn() {
        System.out.println("TV is now ON.");
    }

    @Override
    public void powerOff() {
        System.out.println("TV is now OFF.");
    }

    @Override
    public void changeChannel(int channel) {
        System.out.println("Channel changed to " + channel);
    }
}

public class RemoteTest {
    public static void main(String[] args) {
        Remote tvRemote = new Television();
        tvRemote.powerOn();
        tvRemote.changeChannel(5);
        tvRemote.powerOff();
    }
}