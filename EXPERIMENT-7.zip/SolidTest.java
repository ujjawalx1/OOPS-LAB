abstract class Solid {
    abstract double calculateVolume();
}

class Cuboid extends Solid {
    double length, width, height;

    Cuboid(double length, double width, double height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    @Override
    double calculateVolume() {
        return length * width * height;
    }
}

class Sphere extends Solid {
    double radius;

    Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    double calculateVolume() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
    }
}

public class SolidTest {
    public static void main(String[] args) {
        Solid cuboid = new Cuboid(4, 5, 6);
        Solid sphere = new Sphere(3);

        System.out.println("Cuboid Volume: " + cuboid.calculateVolume());
        System.out.println("Sphere Volume: " + sphere.calculateVolume());
    }
}