
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Calculator");
        JTextField textField = new JTextField();
        textField.setBounds(30, 40, 280, 30);
        frame.add(textField);

        String[] buttons = {
            "7", "8", "9", "/", 
            "4", "5", "6", "*", 
            "1", "2", "3", "-", 
            "0", "=", "C", "+"
        };

        int x = 30, y = 100;
        StringBuilder expression = new StringBuilder();

        for (int i = 0; i < buttons.length; i++) {
            JButton btn = new JButton(buttons[i]);
            btn.setBounds(x, y, 60, 40);
            frame.add(btn);

            btn.addActionListener(e -> {
                String cmd = e.getActionCommand();
                if (cmd.equals("C")) {
                    expression.setLength(0);
                    textField.setText("");
                } else if (cmd.equals("=")) {
                    try {
                        textField.setText(String.valueOf(eval(expression.toString())));
                        expression.setLength(0);
                    } catch (Exception ex) {
                        textField.setText("Error");
                    }
                } else {
                    expression.append(cmd);
                    textField.setText(expression.toString());
                }
            });

            x += 70;
            if ((i + 1) % 4 == 0) {
                x = 30;
                y += 50;
            }
        }

        frame.setSize(350, 350);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static int eval(String expr) {
        return (int) new javax.script.ScriptEngineManager().getEngineByName("JavaScript").eval(expr);
    }
}
