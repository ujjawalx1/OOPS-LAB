
import javax.swing.*;
import java.awt.event.*;
import java.util.Vector;

public class ToDoList {
    public static void main(String[] args) {
        JFrame frame = new JFrame("To-Do List");
        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> list = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);
        JTextField taskField = new JTextField();
        JButton addButton = new JButton("Add");
        JButton removeButton = new JButton("Remove");

        taskField.setBounds(20, 20, 200, 30);
        addButton.setBounds(230, 20, 80, 30);
        scrollPane.setBounds(20, 60, 290, 150);
        removeButton.setBounds(20, 220, 100, 30);

        addButton.addActionListener(e -> {
            String task = taskField.getText();
            if (!task.isEmpty()) {
                listModel.addElement(task);
                taskField.setText("");
            }
        });

        removeButton.addActionListener(e -> {
            int selected = list.getSelectedIndex();
            if (selected != -1) {
                listModel.remove(selected);
            }
        });

        frame.add(taskField);
        frame.add(addButton);
        frame.add(scrollPane);
        frame.add(removeButton);
        frame.setSize(350, 320);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
