
import javax.swing.*;
import java.awt.event.*;

public class RegistrationForm {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Registration Form");
        JLabel nameLabel = new JLabel("Name:");
        JLabel emailLabel = new JLabel("Email:");
        JLabel passLabel = new JLabel("Password:");
        JLabel confirmLabel = new JLabel("Confirm Password:");
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JPasswordField confirmField = new JPasswordField();
        JButton registerButton = new JButton("Register");
        JLabel messageLabel = new JLabel("");

        nameLabel.setBounds(30, 30, 150, 25);
        nameField.setBounds(180, 30, 150, 25);
        emailLabel.setBounds(30, 70, 150, 25);
        emailField.setBounds(180, 70, 150, 25);
        passLabel.setBounds(30, 110, 150, 25);
        passField.setBounds(180, 110, 150, 25);
        confirmLabel.setBounds(30, 150, 150, 25);
        confirmField.setBounds(180, 150, 150, 25);
        registerButton.setBounds(180, 190, 100, 30);
        messageLabel.setBounds(30, 230, 300, 25);

        registerButton.addActionListener(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String pass = new String(passField.getPassword());
            String confirm = new String(confirmField.getPassword());

            if (name.isEmpty() || email.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
                messageLabel.setText("All fields are required.");
            } else if (!email.contains("@")) {
                messageLabel.setText("Invalid email address.");
            } else if (!pass.equals(confirm)) {
                messageLabel.setText("Passwords do not match.");
            } else {
                messageLabel.setText("Registration successful!");
            }
        });

        frame.add(nameLabel);
        frame.add(nameField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(passLabel);
        frame.add(passField);
        frame.add(confirmLabel);
        frame.add(confirmField);
        frame.add(registerButton);
        frame.add(messageLabel);

        frame.setSize(400, 320);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
