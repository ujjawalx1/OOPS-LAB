
import javax.swing.*;
import java.awt.event.*;

public class LoginForm {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Login Form");
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JLabel resultLabel = new JLabel("");

        userLabel.setBounds(50, 30, 100, 30);
        userField.setBounds(150, 30, 150, 30);
        passLabel.setBounds(50, 80, 100, 30);
        passField.setBounds(150, 80, 150, 30);
        loginButton.setBounds(150, 130, 80, 30);
        resultLabel.setBounds(50, 180, 250, 30);

        loginButton.addActionListener(e -> {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if ("admin".equals(username) && "password".equals(password)) {
                resultLabel.setText("Login successful!");
            } else {
                resultLabel.setText("Invalid credentials.");
            }
        });

        frame.add(userLabel);
        frame.add(userField);
        frame.add(passLabel);
        frame.add(passField);
        frame.add(loginButton);
        frame.add(resultLabel);

        frame.setSize(400, 300);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
